function toggleMenu() {
    var menu = document.querySelector('.navbar-menu');
    var burger = document.querySelector('.burger-menu');
    menu.classList.toggle('active');
    burger.classList.toggle('change');
}